/* Author : Ranjan Mishra
 * Date : 5th May 2017
 * Description : Policy
 */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <time.h>

#define MAX_PRICE 100
#define MIN_PRICE 0


#define min(X, Y)  ((X) < (Y) ? (X) : (Y))
#define max(X, Y)  ((X) > (Y) ? (X) : (Y))

#define MAX_AMOUNT 4000
#define TIME 10
#define TRANSITION_LEVEL 9 

#define MAX_POLICY 10
/*
 Let the price changes take place only in exchange and the price is derived in dark pool from the exchange

 The dynamics of the price change in the exchange is given as below


 Price of the stock is given as below function
    
    p_t+1 = p_t( 1+ h1(x_t) + h2(e_t) )
    
    where p_t+1 = price of stock at t+1
          p_t   = price of stock at t
          h1 and h2 are functions 
          x_t = stocks applied to market
          e_t = random variable drwan from N(0,1)
          
          h1(x_t) = [ 0 if x_t < 100, 0.0001 *x_t if 100 < x_t < 10000 and 0.00005 * (x_t)^2 if x_t > 10000 ]
          h2(e_t) = [ 0 if 4*e_t if e_t < -0.3 or e_t > 0.3 and 0 if -0.3 < e_t < 0.3] 
          
    And the ploicy function is taken as parametric function of k_t as follows
    
    x_t = X_t * exp(t-T)/k_t
    where X_t is amount of stocks available to sell at time t
    t is the current time
    T is the total time available
    k_t is the coefficient to be determined

	In the dark pool the execution of the order is uncertain and it is highly unlikely.
	We use technique to understand the nature of distribution in the data.

    
    
    Algorithm for the process goes as follows
    
    1. Let the price range be 0 to 100 and its integer
    2. Calculate the transition probabilities for above range of prices
    3. Initialize the value for k as policy
    4. Improve the policy as per policy iteration method
*/

// function to calculate the transition probability 


typedef struct {
	unsigned priceExchange;
	//unsigned priceDark;
	unsigned amount; 
}state;

typedef struct {
	unsigned actionExchange;
	unsigned actionDark;
	double val;
}actionValue;

actionValue value[TIME][MAX_PRICE][MAX_AMOUNT];
state transitions[TRANSITION_LEVEL];
double prob[TRANSITION_LEVEL];



void init(){
	int i = 0;
	for(i=0;i<TRANSITION_LEVEL;i++){
		transitions[i].priceExchange = 0;
		transitions[i].priceDark = 0;
		transitions[i].amount = 0;
	}
	printf("transition initilization done!\n\n");
}



void assignProbability(){
	prob[0] = 0.04;
	prob[1] = 0.06;
	prob[2] = 0.1;
	prob[3] = 0.06;
	prob[4] = 0.09;
	prob[5] = 0.15;
	prob[6] = 0.1;
	prob[7] = 0.15;
	prob[8] = 0.25;

	printf("Probability assignement done!\n\n");
}



unsigned impactExchange(unsigned price, unsigned amount){

	if(amount <= 100 || price < 3)
		return price;
	else if(amount <= 1000)
		return (unsigned) price*(1 - (0.00008*amount));
	else 
		return (unsigned) price*(1 - (0.01*log(amount)));
}





unsigned impactDark(unsigned priceExchange, unsigned priceDark, unsigned amoutExchange, unsigned amountDark ){
	unsigned value = 0;
	//int vale;
	if(amountDark < 100 || amoutExchange == 0 || priceDark < 3)
		return priceDark;
	else {
		
		value = impactExchange(priceExchange, amoutExchange);
		//printf("%u\n", value);
		value-= min(2, amountDark/amoutExchange);
		//printf("%u\n", vale);
		//value -= vale;
		//printf("%u\n", value);
		return value; 
	}
}



void transition(state st, unsigned darkAmount, unsigned exchangeAmount){
	int i, j;
	//unsigned impactedPriceExchange, impactedPriceDark;
	//impactedPriceExchange = impactExchange(st.priceExchange, exchangeAmount);
	//impactedPriceDark = impactDark(st.priceExchange, st.priceDark, exchangeAmount, darkAmount);

	unsigned k = 0;
	for(i=0;i<3;i++){
		for(j=0;j<3;j++){

			transitions[k].priceDark = min(MAX_PRICE, st.priceDark + j);
			transitions[k].priceExchange = min(MAX_PRICE, st.priceExchange + i);
			transitions[k].amount = st.amount - (darkAmount + exchangeAmount);
			k++;
		}

	}
}



void initializeValue(){
	int i,j,k, iterUp, iterDown;
	state st;
 	for(i=0;i<MAX_PRICE;i++){
 		if(i == 0) { iterUp = 0; iterDown = 2; }
		else if( i== 1) { iterUp = -1; iterDown = 2; }
		else if( i== 98){ iterUp = -2; iterDown = 1;}
		else if( i== 99){ iterUp = -2; iterDown = 0; }
		else { iterUp = -2; iterDown = 2;}
 		
 		for(j=iterUp;j<=iterDown; j++){
 			//printf("%d\n", j);
 			for(k=0;k<MAX_AMOUNT;k++){
 				value[0][i][i+j][k].val = k*impactExchange(i, 25*k);
 				
 			}	
 		}
 	}

 	
}

/* value at the final state is nothing but multiple of price in the primary
   exchange and amount of stocks availble, we need not to explicitly calculate the value at time N-1
   we start with one step ahead and go backward
   we will let k vary from 0 to 100
 */

//double value[100][100][100];


double getValue(unsigned t, state st, unsigned darkAmount, unsigned exchangeAmount){
	double val=0;
	unsigned i=0;
	transition(st, darkAmount, exchangeAmount);

	for(i=0;i<TRANSITION_LEVEL;i++){
		val+= prob[i]*value[t][transitions[i].priceExchange][transitions[i].priceDark][transitions[i].amount].val;
	}
	
	return val;
}




int main(){
	int i, j, k, l, a;
	unsigned x = 0, z =0;
	time_t start_t, end_t;

	int t=0;

	double diff_t;
	double max = 0, val = 0;
	unsigned action = 0, darkAction = 0;
	FILE *fp;
    fp = fopen("output.txt", "w");

    printf("Starting of the program...\n\n");
    time(&start_t);
    state st;

    init();
    assignProbability();
    initializeValue();
    double temp = 0;
    unsigned w = 0;
    int cal = 0;
    int iterUp = 0, iterDown = 0;
	for(t=TIME-1;t>0;t--){
		for(i=0;i<MAX_PRICE;i++){
			
 			if(i == 0) { iterUp = 0; iterDown = 2; }
			else if( i== 1) { iterUp = -1; iterDown = 2; }
			else if( i== 98){ iterUp = -2; iterDown = 1;}
			else if( i== 99){ iterUp = -2; iterDown = 0; }
			else { iterUp = -2; iterDown = 2;}

			
 		
 			for(j=iterUp;j<=iterDown; j++){
 	
					

					for(a=0;a<MAX_AMOUNT;a++){
					//	if(a==15) exit(0);
					max = 0;
					action = 0;
					darkAction = 0;
					st.amount = a;
					
					for(k=0;k<MAX_POLICY;k++){
						//printf("%d", w);
						for(l=0;l<MAX_POLICY;l++){
							
							cal = l*(t-10);		
							temp = pow(2.7, cal);
							//printf("dark : %f\t%d\n", temp, cal);
							z = a*temp;
							cal = k*(t-10);	
							temp = pow(2.7, cal);
							//printf("exchage : %f\t%d\n", temp, cal);
							x = temp*(a-z);
							
							st.priceExchange = impactExchange(i, x*25);
							
							st.priceDark = impactDark(i, i+j, x*25, z*25);
							
							val = (x*st.priceExchange + z*st.priceDark);
							//printf("%f\n", val);
							val+=getValue(10-t-1, st, z, x);
							//printf("%f\n", val);
							//fprintf(fp, "i = %d, j = %d x = %u\t z = %u\t priceE = %u\t priceD = %u\t amount = %u\n", i, j, x, z, impactExchange(i, x*25), impactDark(i, i+j, x*25, z*25), a);

							if (val > max){
								max = val;
								action = k;
								darkAction = l;
							}
							

						}
					}

					value[10-t][i][i+j][a].val = max;
					value[10-t][i][i+j][a].actionExchange = action;
					value[10-t][i][i+j][a].actionDark = darkAction;
					//printf("Value of j: %d", j);
					fprintf(fp, "%d\t%d\t%d\t%f\t%u\t%u\n",a, i, i+j, value[10-t][i][i+j][a].val, value[10-t][i][i+j][a].actionExchange, value[10-t][i][i+j][a].actionDark);
				}
				
				
			}
			//printf("completed %f\n", ((10-t)*(i+1))/10.0);
		}

		printf("time  : %d", t);

	}
	
	
	time(&end_t);
	diff_t = difftime(end_t, start_t);
	printf("\n");

	printf("Execution time = %f\n", diff_t);

	printf("Value at prices : 12, 16 is : %f\n", value[9][15][16][999].val);
	printf("Dark action and exchange action : %u and %u\n", value[9][15][16][999].actionDark, value[9][15][16][999].actionExchange);
	printf("Exiting of the program...\n");
	
	fclose(fp);
	return 0;
}

